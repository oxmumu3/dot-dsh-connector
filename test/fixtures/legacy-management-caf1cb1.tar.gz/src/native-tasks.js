import {randomUUID,randomBytes,createHash,timingSafeEqual} from 'node:crypto';
import {isAbsolute,resolve} from 'node:path';
import {z} from 'zod';
import {redactText} from './harness-reader.js';

const MAX_JOBS=100,MAX_COMMANDS=400,OFFER_MS=15000,LEASE_MS=60000,INSPECT_MS=2000,REPORT_BYTES=256*1024;
const uuid=z.string().uuid();
const nativeId=z.string().regex(/^native_job_[0-9a-f-]{36}$/i);
const commandId=z.string().regex(/^native_cmd_[0-9a-f-]{36}$/i);
const sessionId=z.string().regex(/^dsh_dot_[0-9a-f-]{36}$/i);
const hasControl=value=>Array.from(value).some(character=>{const code=character.codePointAt(0);return code<32||(code>=127&&code<=159);});
const identifier=z.string().min(1).max(512).refine(value=>!hasControl(value));
const requestId=z.string().regex(/^[A-Za-z0-9_-]{1,100}$/);
const ownerId=z.string().regex(/^[A-Za-z0-9_-]{1,100}$/);
const capability=z.string().regex(/^[A-Za-z0-9_-]{43}$/);
const digest=z.string().regex(/^[a-f0-9]{64}$/);
const stamp=z.string().datetime();
const integer=z.number().int().min(0).max(Number.MAX_SAFE_INTEGER);
const cwd=z.string().max(4096).refine(value=>isAbsolute(value)&&resolve(value)===value&&!hasControl(value));
const statuses=['accepted','starting','running','cancel_requested','succeeded','failed','cancelled','unknown'];
const live=new Set(['accepted','starting','running','cancel_requested']);
const definite=new Set(['succeeded','failed','cancelled']);
const workerFailures=['WORKSPACE_UNAVAILABLE','IDENTITY_MISMATCH','NATIVE_UNAVAILABLE','NATIVE_FAILED','NATIVE_TIMEOUT','INVALID_COMMAND','HISTORY_UNAVAILABLE'];
const errors={NATIVE_DENIED:'Native task access denied.',NATIVE_INVALID:'Invalid native task request.',NATIVE_CONFLICT:'Native task request conflicts with existing work.',NATIVE_UNAVAILABLE:'Native task service is unavailable.',NATIVE_CAPACITY:'Native task capacity reached.'};
const fail=code=>Object.assign(new Error(errors[code]??errors.NATIVE_UNAVAILABLE),{code:Object.hasOwn(errors,code)?code:'NATIVE_UNAVAILABLE'});
const checked=(schema,value)=>{const parsed=schema.safeParse(value);if(!parsed.success)throw fail('NATIVE_INVALID');return parsed.data;};
const hash=value=>createHash('sha256').update(value).digest('hex');
const matches=(token,expected)=>typeof token==='string'&&typeof expected==='string'&&timingSafeEqual(Buffer.from(hash(token),'hex'),Buffer.from(expected,'hex'));
const cloned=structuredClone;
const text=value=>redactText(value).text;
const bounded=(value,max)=>{const points=Array.from(text(value));return{text:points.slice(0,max).join(''),truncated:points.length>max};};
const action=z.enum(['create','prompt','inspect','cancel']);
const taskInput=z.string().trim().min(1).max(8000);
const methods={
 harness_start_task:z.strictObject({workspace_id:identifier,task:taskInput,request_id:requestId}),
 harness_get_task:z.strictObject({job_id:nativeId}),
 harness_followup_task:z.strictObject({job_id:nativeId,task:taskInput,request_id:requestId}),
 harness_cancel_task:z.strictObject({job_id:nativeId,expected_revision:integer.optional()}),
};
const eventBase={seq:integer,turn:integer};
const event=z.discriminatedUnion('type',[
 z.strictObject({type:z.literal('turn/start'),...eventBase}),
 z.strictObject({type:z.literal('user/message'),...eventBase,message_id:uuid,source_rpc_id:identifier.optional(),source_kind:z.string().min(1).max(40)}),
 z.strictObject({type:z.literal('assistant/message'),...eventBase,text:z.string().max(64000),interrupted:z.boolean().optional(),text_truncated:z.boolean().optional()}),
 z.strictObject({type:z.literal('turn/end'),...eventBase,reason:z.string().regex(/^[a-z][a-z0-9_-]{0,79}$/)}),
]);
const resultSchema=z.discriminatedUnion('ok',[
 z.strictObject({ok:z.literal(false),error_code:z.enum(workerFailures)}),
 z.strictObject({ok:z.literal(true),session_id:sessionId,workspace_id:identifier,cwd,
  accepted:z.boolean().optional(),cancel_requested:z.boolean().optional(),events:z.array(event).max(256).optional(),
  running:z.boolean().optional(),pending_approvals:integer.optional(),user_question_count:integer.optional(),removed_request_id:uuid.optional(),
 }),
]);
const jobSchema=z.strictObject({
 job_id:nativeId,root_job_id:nativeId,parent_job_id:nativeId.nullable(),principal:ownerId,
 workspace_id:identifier,request_id:requestId,fingerprint:digest,session_id:sessionId,prompt_request_id:uuid,
 message_id:uuid.nullable(),turn:integer.nullable(),status:z.enum(statuses),revision:integer,
 task:z.string().max(8000),result:z.string().max(32000).nullable(),result_truncated:z.boolean(),reason:z.string().max(100).nullable(),
 created_at:stamp,finished_at:stamp.nullable(),observed_at:stamp.nullable(),through_seq:integer.nullable(),
 native_created:z.boolean(),cwd:cwd.nullable(),prompt_accepted:z.boolean(),prompt_attempted:z.boolean().default(false),
 pending_approvals:integer,user_question_count:integer,external_input:z.boolean(),
});
const commandSchema=z.strictObject({
 command_id:commandId,job_id:nativeId,action,status:z.enum(['pending','offered','claimed','reported','expired','superseded']),
 created_at:stamp,finished_at:stamp.nullable(),expires_at:stamp.nullable(),
 claim_hash:digest.nullable(),lease_hash:digest.nullable(),client_id:identifier.nullable(),report_hash:digest.nullable(),
});
const stateSchema=z.strictObject({version:z.literal(2),principal:ownerId,jobs:z.array(jobSchema).max(MAX_JOBS),commands:z.array(commandSchema).max(MAX_COMMANDS),last_worker_seen_at:stamp.nullable()})
 .refine(value=>new Set(value.jobs.map(job=>job.job_id)).size===value.jobs.length&&new Set(value.commands.map(command=>command.command_id)).size===value.commands.length);
const claimSchema=z.strictObject({command_id:commandId,claim_token:capability,client_id:identifier});
const reportSchema=z.strictObject({command_id:commandId,lease_token:capability,client_id:identifier,result:resultSchema});
const pageSchema=z.strictObject({offset:integer.optional(),limit:integer.min(1).max(100).optional(),status:z.enum(statuses).optional()});

/** Durable native task intent. Only an authenticated native worker performs
 * fixed Host operations; this ledger never opens a native cookie or model key.
 * A turn is an immutable attempt. Followups get new jobs in the owned session.
 */
export async function createNativeTasks({store,principal,now=()=>new Date()}={}){
 if(!ownerId.safeParse(principal).success||typeof store?.load!=='function'||typeof store?.save!=='function'||typeof now!=='function')throw fail('NATIVE_INVALID');
 const millis=()=>{const value=now(),time=value instanceof Date?value.getTime():typeof value==='number'?value:NaN;if(!Number.isFinite(time))throw fail('NATIVE_UNAVAILABLE');return time;};
 const time=()=>new Date(millis()).toISOString();
 let state;try{state=stateSchema.parse(await store.load()??{version:2,principal,jobs:[],commands:[],last_worker_seen_at:null});}catch{throw fail('NATIVE_UNAVAILABLE');}
 if(state.principal!==principal)throw fail('NATIVE_DENIED');
 // Older v2 ledgers did not retain this fact beyond bounded command history.
 for(const job of state.jobs)if(job.prompt_accepted||job.message_id!==null||state.commands.some(command=>command.job_id===job.job_id&&command.action==='prompt'&&['claimed','reported','expired'].includes(command.status)))job.prompt_attempted=true;
 let queue=Promise.resolve(),closed=false,closing=false,storageFailed=false;
 const available=()=>{if(closed||closing||storageFailed)throw fail('NATIVE_UNAVAILABLE');};
 const guard=owner=>{available();if(owner!==principal)throw fail('NATIVE_DENIED');};
 const save=async next=>{try{const validated=stateSchema.parse(next);await store.save(validated);state=validated;}catch{storageFailed=true;throw fail('NATIVE_UNAVAILABLE');}};
 const mutate=(job,patch)=>Object.assign(job,patch,{revision:job.revision+1});
 const uncertain=(job,reason)=>{if(!definite.has(job.status))mutate(job,{status:'unknown',reason,result:null,result_truncated:false,through_seq:null,finished_at:time()});};
 const belongs=(value,id)=>{const job=value.jobs.find(item=>item.job_id===id&&item.principal===principal);if(!job)throw fail('NATIVE_DENIED');return job;};
 function enqueue(value,job,kind){
  if(value.commands.some(command=>command.job_id===job.job_id&&command.action===kind&&['pending','offered','claimed'].includes(command.status)))return false;
  while(value.commands.length>=MAX_COMMANDS){const index=value.commands.findIndex(command=>['reported','expired','superseded'].includes(command.status));if(index<0)throw fail('NATIVE_CAPACITY');value.commands.splice(index,1);}
  value.commands.push({command_id:`native_cmd_${randomUUID()}`,job_id:job.job_id,action:kind,status:'pending',created_at:time(),finished_at:null,expires_at:null,claim_hash:null,lease_hash:null,client_id:null,report_hash:null});return true;
 }
 async function expire(){
  const next=cloned(state);let dirty=false;
  for(const command of next.commands){
   if(!['offered','claimed'].includes(command.status)||Date.parse(command.expires_at)>millis())continue;
   if(command.status==='offered')Object.assign(command,{status:'pending',expires_at:null,claim_hash:null});
   else{Object.assign(command,{status:'expired',finished_at:time()});uncertain(belongs(next,command.job_id),'native_reply_unknown');}
   dirty=true;
  }
  if(dirty)await save(next);
 }
 const serial=fn=>{
  try{available();}catch(error){return Promise.reject(error);}
  const work=queue.then(async()=>{available();await expire();return fn();});queue=work.catch(()=>{});return work;
 };
 const restarted=cloned(state);let restartDirty=false;
 for(const job of restarted.jobs)if(live.has(job.status)){uncertain(job,'native_broker_restarted');restartDirty=true;}
 for(const command of restarted.commands)if(['pending','offered','claimed'].includes(command.status)){Object.assign(command,{status:'expired',finished_at:time(),claim_hash:null,lease_hash:null});restartDirty=true;}
 if(restartDirty)await save(restarted);

 function view(job,{summary=false,duplicate=false}={}){
  const out={job_id:job.job_id,root_job_id:job.root_job_id,parent_job_id:job.parent_job_id,project_id:job.workspace_id,workspace_id:job.workspace_id,
   execution_kind:'native',session_id:job.session_id,message_id:job.message_id,turn:job.turn,status:job.status,revision:job.revision,
   task:bounded(job.task,summary?500:8000).text,result_truncated:job.status==='succeeded'&&job.result_truncated,reason:job.reason,
   created_at:job.created_at,finished_at:job.finished_at,observed_at:job.observed_at,
   pending_approvals:job.pending_approvals,user_question_count:job.user_question_count,acceptance:'unverified',duplicate,
   stale:job.observed_at===null||millis()-Date.parse(job.observed_at)>INSPECT_MS*2};
  if(!summary)out.result=job.status==='succeeded'&&job.result!==null?bounded(job.result,16000).text:null;
  return out;
 }
 function commandView(command,job){return{command_id:command.command_id,action:command.action,job_id:job.job_id,workspace_id:job.workspace_id,
  session_id:job.session_id,request_id:job.prompt_request_id,...job.cwd?{expected_cwd:job.cwd}:{},...command.action==='prompt'?{task:job.task}:{}};}
 const requestFingerprint=args=>hash(JSON.stringify(args));
 function priorRequest(value,request_id,fingerprint){const prior=value.jobs.find(job=>job.principal===principal&&job.request_id===request_id);if(prior&&prior.fingerprint!==fingerprint)throw fail('NATIVE_CONFLICT');return prior;}
 function newJob(value,{workspace_id,task,request_id,parent=null,fingerprint}){
  if(value.jobs.length>=MAX_JOBS)throw fail('NATIVE_CAPACITY');
  const job_id=`native_job_${randomUUID()}`,created_at=time();
  const job={job_id,root_job_id:parent?.root_job_id??job_id,parent_job_id:parent?.job_id??null,principal,workspace_id,task,request_id,fingerprint,
   session_id:parent?.session_id??`dsh_dot_${randomUUID()}`,prompt_request_id:randomUUID(),message_id:null,turn:null,status:'accepted',revision:0,
   result:null,result_truncated:false,reason:null,created_at,finished_at:null,observed_at:null,through_seq:parent?.through_seq??null,
   native_created:parent?.native_created??false,cwd:parent?.cwd??null,prompt_accepted:false,prompt_attempted:false,pending_approvals:0,user_question_count:0,external_input:false};
  value.jobs.push(job);enqueue(value,job,parent?'prompt':'create');return job;
 }
 async function call(owner,tool,args){
  guard(owner);if(!Object.hasOwn(methods,tool))throw fail('NATIVE_INVALID');const parsed=checked(methods[tool],args);
  return serial(async()=>{
   guard(owner);
   if(tool==='harness_start_task'){
    const fingerprint=requestFingerprint({tool,...parsed});const prior=priorRequest(state,parsed.request_id,fingerprint);if(prior)return view(prior,{duplicate:true});
    const next=cloned(state),job=newJob(next,{...parsed,fingerprint});await save(next);return view(job);
   }
   const found=belongs(state,parsed.job_id);
   if(tool==='harness_followup_task'){
    const fingerprint=requestFingerprint({tool,...parsed});const prior=priorRequest(state,parsed.request_id,fingerprint);if(prior)return view(prior,{duplicate:true});
    if(!definite.has(found.status)||!found.native_created||state.jobs.some(job=>job.parent_job_id===found.job_id)||state.jobs.some(job=>job.root_job_id===found.root_job_id&&live.has(job.status)))throw fail('NATIVE_CONFLICT');
    const next=cloned(state),job=newJob(next,{workspace_id:found.workspace_id,task:parsed.task,request_id:parsed.request_id,parent:found,fingerprint});await save(next);return view(job);
   }
   if(tool==='harness_get_task'){
    if(!definite.has(found.status)){
     const next=cloned(state),job=belongs(next,found.job_id);
     if(!next.commands.some(command=>command.job_id===job.job_id&&['pending','offered','claimed'].includes(command.status)&&command.action!=='inspect')){
      if(enqueue(next,job,'inspect'))await save(next);
     }
    }
    return view(belongs(state,found.job_id));
   }
   if(parsed.expected_revision!==undefined&&parsed.expected_revision!==found.revision)throw fail('NATIVE_CONFLICT');
   if(definite.has(found.status))return view(found);
   const next=cloned(state),job=belongs(next,found.job_id);
   const mutations=next.commands.filter(command=>command.job_id===job.job_id&&['create','prompt'].includes(command.action));
   const mayHavePrompted=job.prompt_attempted||job.prompt_accepted||mutations.some(command=>command.action==='prompt'&&['claimed','reported','expired'].includes(command.status));
   for(const command of next.commands)if(command.job_id===job.job_id&&['pending','offered'].includes(command.status))Object.assign(command,{status:'superseded',finished_at:time()});
   if(!mayHavePrompted&&!mutations.some(command=>command.status==='claimed'))mutate(job,{status:'cancelled',reason:'cancelled_before_prompt',result:null,finished_at:time()});
   else{mutate(job,{status:'cancel_requested',reason:null,finished_at:null});enqueue(next,job,'cancel');}
   await save(next);return view(job);
  });
 }
 async function offer(owner){
  guard(owner);return serial(async()=>{
   guard(owner);const next=cloned(state);let dirty=false;
   for(const job of next.jobs)if(['running','cancel_requested'].includes(job.status)&&job.prompt_accepted&&(job.observed_at===null||millis()-Date.parse(job.observed_at)>=INSPECT_MS)
    &&!next.commands.some(command=>command.job_id===job.job_id&&['pending','offered','claimed'].includes(command.status))){dirty=enqueue(next,job,'inspect')||dirty;}
   const command=next.commands.find(item=>item.status==='pending'&&!next.commands.some(other=>other.job_id===item.job_id&&['offered','claimed'].includes(other.status)));
   if(!command){if(dirty)await save(next);return null;}
   const claim_token=randomBytes(32).toString('base64url');Object.assign(command,{status:'offered',claim_hash:hash(claim_token),expires_at:new Date(millis()+OFFER_MS).toISOString()});
   await save(next);return{command_id:command.command_id,claim_token,expires_at:command.expires_at};
  });
 }
 async function claim(input){
  const args=checked(claimSchema,input);return serial(async()=>{
   const next=cloned(state),command=next.commands.find(item=>item.command_id===args.command_id);
   if(!command||command.status!=='offered'||Date.parse(command.expires_at)<=millis()||!matches(args.claim_token,command.claim_hash))throw fail('NATIVE_DENIED');
   const lease_token=randomBytes(32).toString('base64url');Object.assign(command,{status:'claimed',lease_hash:hash(lease_token),client_id:args.client_id,expires_at:new Date(millis()+LEASE_MS).toISOString()});next.last_worker_seen_at=time();
   const job=belongs(next,command.job_id);if(command.action==='create'&&job.status==='accepted')mutate(job,{status:'starting'});
   if(command.action==='prompt')job.prompt_attempted=true;
   await save(next);return{command:commandView(command,job),lease_token,expires_at:command.expires_at};
  });
 }
 function reduce(job,events){
  const previousThrough=job.through_seq;let seq=previousThrough,proofIncomplete=false;
  for(const item of [...events].sort((a,b)=>a.seq-b.seq)){
   if(seq!==null&&item.seq<=seq)continue;
   seq=item.seq;
   if(item.type==='user/message'){
    if(item.source_rpc_id===job.prompt_request_id&&item.source_kind==='user'){
     if(job.message_id!==null&&(job.message_id!==item.message_id||job.turn!==item.turn)){uncertain(job,'native_identity_mismatch');job.external_input=true;continue;}
     job.message_id=item.message_id;job.turn=item.turn;job.prompt_accepted=true;
     if(!definite.has(job.status)&&job.status!=='cancel_requested')Object.assign(job,{status:'running',finished_at:null,reason:null});
    }else if(item.source_kind==='user'&&job.turn!==null&&item.turn===job.turn){job.external_input=true;uncertain(job,'native_external_input');}
   }else if(job.turn!==null&&item.turn===job.turn&&!job.external_input){
    if(item.type==='assistant/message'&&item.interrupted!==true&&item.text.trim()){
     const result=bounded(item.text,16000);job.result=result.text;job.result_truncated=result.truncated||item.text_truncated===true;
    }else if(item.type==='turn/end'){
     if(item.reason==='completed'&&!job.result?.trim()){uncertain(job,'native_result_unavailable');proofIncomplete=true;continue;}
     Object.assign(job,{status:item.reason==='completed'?'succeeded':['aborted','cancelled'].includes(item.reason)?'cancelled':'failed',reason:item.reason,finished_at:time(),pending_approvals:0,user_question_count:0});
     if(job.status!=='succeeded'){job.result=null;job.result_truncated=false;}
    }
   }
  }
  // A bounded native page may omit older request or assistant records. Keep
  // the earlier cursor until proof is complete so a fuller page can recover it.
  job.through_seq=job.message_id===null||proofIncomplete?previousThrough:seq;
 }
 async function report(input){
  let bytes;try{bytes=Buffer.byteLength(JSON.stringify(input));}catch{throw fail('NATIVE_INVALID');}if(bytes>REPORT_BYTES)throw fail('NATIVE_INVALID');
  const args=checked(reportSchema,input),report_hash=hash(JSON.stringify(args.result));
  return serial(async()=>{
   const next=cloned(state),command=next.commands.find(item=>item.command_id===args.command_id);
   if(!command||command.client_id!==args.client_id||!matches(args.lease_token,command.lease_hash))throw fail('NATIVE_DENIED');
   const job=belongs(next,command.job_id);
   if(command.status==='reported'){
    if(command.report_hash!==report_hash)throw fail('NATIVE_CONFLICT');return{accepted:true,duplicate:true,job:view(job)};
   }
   if(command.status!=='claimed'||Date.parse(command.expires_at)<=millis())throw fail('NATIVE_DENIED');
   if(args.result.ok&&(args.result.session_id!==job.session_id||args.result.workspace_id!==job.workspace_id||(job.cwd!==null&&args.result.cwd!==job.cwd)))throw fail('NATIVE_DENIED');
   Object.assign(command,{status:'reported',report_hash,finished_at:time()});next.last_worker_seen_at=time();
   if(!args.result.ok){
    if(!definite.has(job.status)){
     if(command.action==='create'&&['WORKSPACE_UNAVAILABLE','INVALID_COMMAND'].includes(args.result.error_code))mutate(job,{status:'failed',reason:args.result.error_code,result:null,finished_at:time()});
     else uncertain(job,args.result.error_code);
    }
   }else{
    const result=args.result;job.native_created=true;job.cwd??=result.cwd;job.observed_at=time();
    job.pending_approvals=result.pending_approvals??0;job.user_question_count=result.user_question_count??0;
    if(command.action==='create'){
     if(job.status==='cancel_requested'){mutate(job,{status:'cancelled',reason:'cancelled_before_prompt',finished_at:time()});for(const pending of next.commands)if(pending.job_id===job.job_id&&['pending','offered'].includes(pending.status))Object.assign(pending,{status:'superseded',finished_at:time()});}
     else if(!definite.has(job.status)){mutate(job,{status:'accepted',reason:null,finished_at:null});enqueue(next,job,'prompt');}
    }else if(command.action==='prompt'){
     if(result.accepted!==true)uncertain(job,'native_prompt_unconfirmed');
     else{job.prompt_accepted=true;if(job.status!=='cancel_requested'&&!definite.has(job.status))mutate(job,{status:'running',reason:null,finished_at:null});}
    }else if(command.action==='cancel'&&!definite.has(job.status)){
     if(result.removed_request_id===job.prompt_request_id&&job.turn===null)mutate(job,{status:'cancelled',reason:'native_queue_removed',result:null,finished_at:time()});
     else mutate(job,{status:'cancel_requested',reason:null,finished_at:null});
    }
    if(result.events?.length){reduce(job,result.events);job.revision++;}
    if(!live.has(job.status)&&job.status!=='unknown')for(const pending of next.commands)if(pending.job_id===job.job_id&&['pending','offered'].includes(pending.status))Object.assign(pending,{status:'superseded',finished_at:time()});
   }
   await save(next);return{accepted:true,duplicate:false,job:view(job)};
  });
 }
 function jobs(input={}){
  available();const {offset=0,limit=20,status}=checked(pageSchema,input),items=state.jobs.filter(job=>status===undefined||job.status===status).toReversed();
  return{items:items.slice(offset,offset+limit).map(job=>view(job,{summary:true})),total:items.length,offset,next_offset:offset+limit<items.length?offset+limit:null,has_more:offset+limit<items.length};
 }
 function job(id){available();checked(nativeId,id);return view(belongs(state,id));}
 function overview(){available();const counts=Object.fromEntries(statuses.map(status=>[status,state.jobs.filter(job=>job.status===status).length]));return{jobs_total:state.jobs.length,counts,queued:state.commands.filter(command=>['pending','offered'].includes(command.status)).length,claimed:state.commands.filter(command=>command.status==='claimed').length,last_worker_seen_at:state.last_worker_seen_at};}
 let closePromise;
 return{call,offer,claim,report,jobs,job,overview,close(){if(closePromise)return closePromise;closing=true;closePromise=(async()=>{await queue;closed=true;await store.close?.();})();return closePromise;}};
}
